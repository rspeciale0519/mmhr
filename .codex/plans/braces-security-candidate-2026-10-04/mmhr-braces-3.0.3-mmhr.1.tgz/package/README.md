# MMHR braces security fork

This private package starts from the exact installed `braces@3.0.3` source.
It is a proposed replacement. MMHR has not installed it.
The depth policy is a root-selected draft, pending human package approval.

The patch limits combined brace and parenthesis nesting to 100 containers.
The new `maxDepth` option accepts nonnegative finite integers only.
An absent value uses 100. Values above 100 cannot raise the limit.
Zero permits text without containers.
Invalid supplied values cause an error.

Compile, expand, and stringify also validate supplied ASTs before recursive work.
The validator rejects child or parent cycles, shared child nodes, accessor fields, custom array properties, and malformed values.
It requires plain node objects and plain arrays.
Parser-compatible paren shapes can retain NaN counters.
This exception does not alter cycle, value, or depth checks.
Descriptor facts use a cache within each validation call.
The next call validates changed AST data again.
Supplied ASTs can contain at most 20,003 nodes.
The bound uses two nodes per default maximum input character, plus root, BOS, and EOS.
Nested expansion arrays use an iterative walk with the same hard depth limit.
The patch checks each actual range transform result before fill-range string conversion.
The wrapper keeps the callback receiver and all callback arguments.
Compile paths that ignore transforms still ignore them.
Plain finite arrays and supported primitive results keep their original values.
Objects, functions, symbols, accessors, cycles, and excessive array depth cause an error.
The callback itself remains application code. This package does not isolate its execution.

Ordinary parsing, escaping, output order, and range behavior retain the installed base implementation.
The patch removes one compile debug output.
The existing `maxLength` and `rangeLimit` behavior stays unchanged.
This patch does not bound every possible Cartesian expansion.
Explicit large range limits can still require substantial memory.

The upstream pull request supplied the depth-guard design.
This fork does not copy its unrelated parser changes.
`SOURCE-PROVENANCE.json` identifies the exact base and reference commit.
`LICENSE` retains the upstream MIT notice.

This package has no install scripts or native components.
It uses the existing `fill-range@7.1.1` dependency.
It has no bank, email, account, or provider connection.

The application owner must approve installation after source and compatibility review.
Node 22 and Linux acceptance require separate checks.
